<?php
	if(isset($_GET['date']) && $_GET['time'] ):
	$time = $_GET['time'];
	$date = $_GET['date'];
?>
<div class="col-md-6">
	<div class='panel panel-default'>
		<div class='panel-heading'><div class='panel-title'> Meeting Form </div></div>
			<div class="panel-body">
				<p>Date: <?php echo $_GET['date']?></p>
				<p>Time: <?php echo $_GET['time']?></p>
				<p>Time Zone:  <?php echo $_GET['timezone'];?></p>
			</div>
	</div>
</div>
<div class="col-md-6">
	<div class='panel panel-default'>
	<div class='panel-heading'><div class='panel-title'> Meeting Form </div></div>
	<div class="panel-body">
			<form id="SaveForm" enctype='multipart/form-data' action='insert_shedule.php' method="post">
				<div class="form-group">
					<label>Time</label>
					<input  type='text' disabled="disabled" class="form-control" value="<?php echo $_GET['time']?>"> 
					<input id="time" name='time' type='hidden' class="form-control" value="<?php echo $_GET['time']?>"> 
				</div>
				<div class="form-group">
					<label>Time Zone</label>
					<input  type='text' disabled="disabled" class="form-control" value="<?php echo $_GET['timezone']?>"> 
					<input id="timezone" name='timezone' type='hidden' class="form-control" value="<?php echo $_GET['timezone']?>"> 
				</div>
				<div class="form-group">
				 <label>Date</label>
					<input disabled="disabled" class="form-control" value="<?php echo $_GET['date']?>"> 
					<input id="date" name='date' type='hidden' class="form-control" value="<?php echo $_GET['date']?>"> 
				</div>
				
				<div class="form-group">
					<label>Name</label>
					<input name="name" class='form-control' type="" id="name" />
				</div>
				
				
				<div class="form-group">
					<label>Email</label>
					<input name="email" class='form-control' type="email" id="email" />
				</div>
				
				
				<div class="form-group">
					<label>Your skype/Project Name</label>
					<input name="number" class='form-control' type="" id="number" />
				</div>
				
				<div class="form-group">
					<label>Website</label>
					<input name="website" class='form-control' type="" id="website" />
				</div>
				
				<div class="form-group">
					<label>Other Related Details</label>
					<textarea name="details" class='form-control' type="" id="details" ></textarea>
				</div>
				
				<button onclick="run()" name="submit" id="save" class='btn btn-submit' >Shedule Event</button>
			</form>
		</div>
	</div>
</div>
<?php endif;?>