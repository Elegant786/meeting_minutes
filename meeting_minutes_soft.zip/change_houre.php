<?php
if(isset($_GET['houre'])){
?>
<div class="col-md-3">
			<input name="date" type="hidden" id="date" value="<?php echo $_GET['date']?>" />
			<table class="table">
				<thead>
					<tr>
						<td>Select Time To set Meeting</td>
					</tr>
				</thead>
					
				<?php
					if($_GET['houre']==24){
				?>
					<tbody>					
						<?php
							$timezone = $_GET['timezone'];
							date_default_timezone_set($timezone);	
							if($_GET['date'] == date("Y-m-d")){
									$time=date("H:i");
								}else{
									$time ="08:30";
								}
														
								function roundToQuarterHour($timestring) {
									$minutes = date('i', strtotime($timestring));
									return $minutes - ($minutes % 30);
								}
								
									for($i=0;$i<=48;$i++){
										if($time == "20:00"){
											break;
										}else{
										$time = date('H:i', strtotime($time.'+30 minute'));	
										$h = substr($time,0,-3);
										$newTime = explode(":",$time);
										$m = $newTime[1];
										$m = roundToQuarterHour($time);
										if($m == 0){
											$time = $h.":00";
										}else{
											$time = $h.":".$m;
										}
										
						?>

						<tr class="val">
		<td> 
			<button style="display:block;" name="" class="btn btn-succcess btn-block" type='submit' id='<?php echo "btn1".$i?>' onclick="Confirmation(this.value,Show<?php echo $i?>.id)" value="<?php echo "btn1".$i?>" /><?php echo $time;?></button>
			<button style="display:none;" class="btn btn-block btn-bg btn-success" id="Show<?php echo $i?>" name="<?php echo $_GET['date']?>" onclick="get_form(this.name, this.value,timzeZone.value)" type="submit" value="<?php echo $time;?>">Confirm</button>
		</td>
						</tr>
										<?php } }?>
					</tbody>

					<?php }elseif($_GET['houre']=='12'){?>
						<tbody>
						<?php
						
						$timezone = $_GET['timezone'];
						date_default_timezone_set($timezone);
							if($_GET['date']==date("Y-m-d")){
							$start = date("H:i");
							}else{
								$start = '08:00';
							}
							$end ="23:30";
							$tStart = strtotime($start);
							$tEnd = strtotime($end);
							$tNow = $tStart;
							while ($tNow <= $tEnd) {
							$time = date('h:i', $tNow);
							$round = 30*60;
							$rounded = round($tNow / $round) * $round;
							
							$time = date("h:i A", $rounded);
							$tNow = strtotime('+30 minutes', $tNow);
							@$i++;
							
							
						
						?>
						<tr>
					<td> 
						<button style="display:block;" name="" class="btn btn-succcess btn-block" type='submit' id='<?php echo "btn1".$i?>' onclick="Confirmation(this.value,Show<?php echo $i?>.id)" value="<?php echo "btn1".$i?>" /><?php echo $time;?></button>
						<button style="display:none;" class="btn btn-block btn-bg btn-success" id="Show<?php echo $i?>" name="<?php echo $_GET['date']?>" onclick="get_form(this.name, this.value,timzeZone.value)" type="submit" value="<?php echo $time;?>">Confirm</button>
					</td></tr>
							<?php }?>

							
						</tbody>
					
					<?php }?>
					
					
					
			</table>
			
		</div>
<?php }?>
