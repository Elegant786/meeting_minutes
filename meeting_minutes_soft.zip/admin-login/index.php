<?php session_start(); ob_start();
if(isset($_SESSION['username'])){
	header("Location:dashboard.php?page=home");
}
require("../config.php");

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" >
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.html" >
    <link rel="icon" type="image/png" href="assets/img/favicon.png" >
    <meta http-equiv="X-UA-Compatible" content="IE=edge" >
    <title>Meeting</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no' name='viewport' >
    <meta name="viewport" content="width=device-width" >

    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" >

    <!--  Paper Dashboard CSS    -->
    <link href="assets/css/amaze.css" rel="stylesheet" >
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/font-muli.css" rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/vendors/sweetalert/css/sweetalert2.min.css" rel="Stylesheet" >
</head>

<body>
    <nav class="navbar navbar-primary navbar-transparent navbar-absolute">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index.php">Set a meeting</a>
            </div>
        </div>
    </nav>
    <div class="wrapper wrapper-full-page">
        <div class="full-page login-page"  data-color="blue">
            <!--   you can change the color of the filter page using: data-color="blue | purple | green | orange | red | rose " -->
            <div class="content">
                <div class="container">
                    <div class="row">
					<div class="col-md-12 text-center">
						<?php
							if(isset($_REQUEST['login']) && $_REQUEST['login']=="login"){
								$email = $_POST['email'];
								$pass = $_POST['password'];
								$pass = trim(str_replace(" ","",$pass));								
								$password = md5("2017@++".$pass);
								$sql = "SELECT * FROM `admin` WHERE `email` = '".$email."' AND `password` = '".$password."'";
								$query =mysqli_query($connect,$sql);
								if(mysqli_num_rows($query)==1){
									while($row = mysqli_fetch_assoc($query)){
										$_SESSION['username'] = $row['username'];
										$_SESSION['admin_id']    = $row['admin_id'];
										$_SESSION['password']    = $row['password'];
										$_SESSION['role']    = $row['role'];
										header("Location:dashboard.php?page=home");
									}
								}else{
									echo "<div class='alert alert-danger'> Email Or Password Not Matched !!! </div>";
								}
								
							}
						?>
					</div>
                        <div class="col-md-4 col-sm-6 col-md-offset-4 col-sm-offset-3">
								
                            <form method="post" action="">
                                <div class="card card-login card-hidden">
                                    <div class="header text-center">
                                        <h3 class="title">Login</h3>
                                    </div>
                                    <div class="content">
										
										<h5 class="text-center">Meeting Dashboard</h5>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" placeholder="email" name='email' class="form-control input-no-border">
                                        </div>
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" name='password' placeholder="Password" class="form-control input-no-border">
                                        </div>
										
										<div class='form-group'>
											<button type='submit' name='login' value='login' class='btn btn-success btn-block'><i class='fa fa-lock'></i> Login</button>
										</div>
                                    </div>
									
                                   <!--  <div class="text-center">
                                        <button type="submit" class="btn btn-rose btn-wd btn-lg">Sign In</button>
                                        <p>New to Amaze?&nbsp;&nbsp;
                                        	<a href="register.html">
                            					<i class="ti-id-badge"></i> Register
                        					</a>
                        				</p>

                                    </div>-->
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul>
                            <li>
                                <a href="#">
                                    Home
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Company
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Portfolio
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Blog
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                        <a href="#">Amaze Admin</a>
                    </p>
                </div>
            </footer>
        </div>
    </div>
<!--   Core JS Files   -->
<script src="assets/vendors/jquery-3.1.1.min.js" type="text/javascript"></script>
<script src="assets/vendors/jquery-ui.min.js" type="text/javascript"></script>
<script src="assets/vendors/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/vendors/material.min.js" type="text/javascript"></script>
<script src="assets/vendors/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
<!-- Forms Validations Plugin -->
<script src="assets/vendors/jquery.validate.min.js"></script>
<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
<script src="assets/vendors/moment.min.js"></script>
<!--  Charts Plugin -->
<script src="assets/vendors/chartist.min.js"></script>
<!--  Plugin for the Wizard -->
<script src="assets/vendors/jquery.bootstrap-wizard.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/vendors/bootstrap-notify.js"></script>
<!-- DateTimePicker Plugin -->
<script src="assets/vendors/bootstrap-datetimepicker.js"></script>
<!-- Vector Map plugin -->
<script src="assets/vendors/jquery-jvectormap.js"></script>
<!-- Sliders Plugin -->
<script src="assets/vendors/nouislider.min.js"></script>
<!-- Select Plugin -->
<script src="assets/vendors/jquery.select-bootstrap.js"></script>
<!--  DataTables.net Plugin    -->
<script src="assets/vendors/jquery.datatables.js"></script>
<!-- Sweet Alert 2 plugin -->
<script src="assets/vendors/sweetalert/js/sweetalert2.min.js"></script>
<!--	Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
<script src="assets/vendors/jasny-bootstrap.min.js"></script>
<!--  Full Calendar Plugin    -->
<script src="assets/vendors/fullcalendar.min.js"></script>
<!-- TagsInput Plugin -->
<script src="assets/vendors/jquery.tagsinput.js"></script>
<!-- Material Dashboard javascript methods -->
<script src="assets/js/amaze.js"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->
<script src="assets/js/demo.js"></script>
<script type="text/javascript">
    $().ready(function() {
        demo.checkFullPageBackgroundImage();

        setTimeout(function() {
            // after 1000 ms we add the class animated to the login/register card
            $('.card').removeClass('card-hidden');
        }, 700)
    });
</script>
</body>

<!-- Mirrored from www.urbanui.com/amaze/pages/sample-pages/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 25 Feb 2018 09:26:25 GMT -->
</html>
