 <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card">
								<div class="content">
									<div class="row">
										<div class="col-xs-5">
											<div class="icon-big icon-warning text-center">
												<i class="ti-stats-up"></i>
											</div>
										</div>
										<div class="col-xs-7">
											<div class="numbers">
												<p>Visitors</p>
												70,340
											</div>
										</div>
									</div>
								</div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="ti-alert text-warning"></i> 65% lower than last month
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card">
								<div class="content">
									<div class="row">
										<div class="col-xs-5">
											<div class="icon-big icon-danger text-center">
												<i class="ti-receipt"></i>
											</div>
										</div>
										<div class="col-xs-7">
											<div class="numbers">
												<p>Orders</p>
												102
											</div>
										</div>
									</div>
								</div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="ti-tag text-warning"></i> Product-wise sales
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card">
								<div class="content">
									<div class="row">
										<div class="col-xs-5">
											<div class="icon-big icon-success text-center">
												<i class="ti-money"></i>
											</div>
										</div>
										<div class="col-xs-7">
											<div class="numbers">
												<p>Revenue</p>
												$23,100
											</div>
										</div>
									</div>
								</div>
								<div class="card-footer">
                                    <div class="stats">
                                        <i class="ti-calendar"></i> Weekly sales
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card">
								<div class="content">
									<div class="row">
										<div class="col-xs-5">
											<div class="icon-big icon-info text-center">
												<i class="ti-twitter"></i>
											</div>
										</div>
										<div class="col-xs-7">
											<div class="numbers">
												<p>Followers</p>
												+245
											</div>
										</div>
									</div>
								</div>
								<div class="card-footer">
                                    <div class="stats">
                                        <i class="ti-reload"></i> Just Updated
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="header card-header-icon">
                                    <h4 class="title"><i class="ti-world"></i> Global Sales by Top Locations</h4>
                                </div>
                                <div class="content">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="table-responsive table-sales">
											<table class="table">
												<tbody>
													<tr>
														<td>
															<div class="flag">
																<img src="assets/img/flags/US.png" alt="">
															</div>
														</td>
														<td>USA</td>
														<td class="text-right">
															2.920
														</td>
														<td class="text-right">
															53.23%
														</td>
													</tr>
													<tr>
														<td>
															<div class="flag">
																<img src="assets/img/flags/DE.png" alt="">
															</div>
														</td>
														<td>Germany</td>
														<td class="text-right">
															1.300
														</td>
														<td class="text-right">
															20.43%
														</td>
													</tr>
													<tr>
														<td>
															<div class="flag">
																<img src="assets/img/flags/AU.png" alt="">
															</div>
														</td>
														<td>Australia</td>
														<td class="text-right">
															760
														</td>
														<td class="text-right">
															10.35%
														</td>
													</tr>
													<tr>
														<td>
															<div class="flag">
																<img src="assets/img/flags/GB.png" alt="">
															</div>
														</td>
														<td>United Kingdom</td>
														<td class="text-right">
															690
														</td>
														<td class="text-right">
															7.87%
														</td>
													</tr>
													<tr>
														<td>
															<div class="flag">
																<img src="assets/img/flags/RO.png" alt="">
															</div>
														</td>
														<td>Romania</td>
														<td class="text-right">
															600
														</td>
														<td class="text-right">
															5.94%
														</td>
													</tr>
													<tr>
														<td>
															<div class="flag">
																<img src="assets/img/flags/BR.png" alt="">
															</div>
														</td>
														<td>Brasil</td>
														<td class="text-right">
															550
														</td>
														<td class="text-right">
															4.34%
														</td>
													</tr>
												</tbody>
											</table>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-md-offset-1">
                                            <div id="worldMap" class="map"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>