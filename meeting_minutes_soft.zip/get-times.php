<?php 
require_once('config.php');
?>
<!DOCTYPE html>
<html>
<head>

<meta charset='utf-8' />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link href="style.css" rel="stylesheet" />
<script src='lib/jquery.min.js'></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

</head>
<body>
<header>
	<nav class="navbar navbar-default">
		  <div class="container">
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			  <a class="navbar-brand" href="index.php">Project name</a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
			  <ul class="nav navbar-nav">
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="#about">About</a></li>
				<li><a href="#contact">Contact</a></li>
				<li class="dropdown">
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
				  <ul class="dropdown-menu">
					<li><a href="#">Action</a></li>
					<li><a href="#">Another action</a></li>
					<li><a href="#">Something else here</a></li>
					<li role="separator" class="divider"></li>
					<li class="dropdown-header">Nav header</li>
					<li><a href="#">Separated link</a></li>
					<li><a href="#">One more separated link</a></li>
				  </ul>
				</li>
			  </ul>
			 
			</div><!--/.nav-collapse -->
		  </div>
		</nav>

</header>

<section class="container ">
  <div class='row'>
	<div class="col-md-12 myBgGreen">
		<div class="col-md-3 myPadding-15"> <p id='myzone'>Your TimeZone: <?php echo $time_zone?> </p> </div>
		
		<div class="col-md-3 myPadding-15">
			
				<div class="switch">
				  <input  onchange="changeTime(this.value,timzeZone.value,setDate.value)" name="switch" value='12' id="12" type="radio"/>
				  <label for="one" class="switch__label">12</label>
				  <input checked='checked'  onchange="changeTime(this.value,timzeZone.value,setDate.value)" name="switch" value='24' id="24" type="radio" />
				  <label for="two" class="switch__label">24</label>				  
				  <div class="switch__indicator" /></div>
				</div>
			
		</div>
		
		<div class="col-md-3 myPadding-15 pull-right">
			<input type='hidden' id='setDate' value="<?php echo $_GET['date']?>" />
			<select id='timzeZone' onchange="ChangeTimeZone(this.value,setDate.value)" class='form-control Select2'>			  
			  <option value="<?php echo $time_zone?>" ><?php echo $time_zone?></option><?php
					$zones = generate_timezone_list();
					foreach($zones AS $Area => $zone){
				?>
			  <option value="<?php echo $Area?>"><?php echo $zone?></option>
			  <?php }?>
			</select>
		</div>
	</div>
		<div id="Ajax">
			
		</div>
	
		<!-- Time  Start -->
		<div id="default">
		 <div class="col-md-3">
			<input name="date" type="hidden" id="date" value="<?php echo $_GET['date']?>" />
			<table class="table">
				<thead>
					<tr>
						<td>Select Time To set Meeting</td>
					</tr>
				</thead>
					
				
					<tbody>
						
						<?php
						   if($_GET['date'] == date("Y-m-d")){
									$time=date("H:i");
								}else{
									$time ="07:30";
								}
								date_default_timezone_set($time_zone);
								function roundToQuarterHour($timestring) {
									$minutes = date('i', strtotime($timestring));
									return $minutes - ($minutes % 30);
									
								}								
									for($i=0;$i<=48;$i++){
										if($time == "20:00"){
											break;
										}else{
										$time = date('H:i', strtotime($time.'+30 minute'));	
										$h = substr($time,0,-3);
										$newTime = explode(":",$time);
										$m = $newTime[1];
										$m = roundToQuarterHour($time);
										if($m == 0){
											$time = $h.":00";
										}else{
											$time = $h.":".$m;
										}
										
						?>

						<tr class="val">
		<td> 
			<button style="display:block;" name="" class="btn btn-succcess btn-block" type='submit' id='<?php echo "btn1".$i?>' onclick="Confirmation(this.value,Show<?php echo $i?>.id)" value="<?php echo "btn1".$i?>" /><?php echo $time;?></button>
			<button style="display:none;" class="btn btn-block btn-bg btn-success" id="Show<?php echo $i?>" name="<?php echo $_GET['date']?>" onclick="get_form(this.name, this.value,timzeZone.value )" type="submit" value="<?php echo $time;?>">Confirm</button>
		</td>
						</tr>
										<?php } }?>
					</tbody>				
			</table>
			
		</div> 
		
	</div><!-- Default Times-->
		
		<div id='ShowForm' class='col-md-9'>
			
		</div>
		<!-- Time End -->
  </div>
  <!-- <input onclick="get_form(this.value , date.value)" type="submit" value="<?php echo $time;?>" class="">  -->
  
</section>
<script>
	function get_form(date,time,timezone) {
	  var xhttp; 
	  if (time == "") {
		document.getElementById("ShowForm").innerHTML = "";
		return;
	  }
	  xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
		document.getElementById("ShowForm").innerHTML = this.responseText;
		}
	  };
	  xhttp.open("GET", "form.php?time="+time+"&date="+date+"&timezone="+timezone, true);
	  xhttp.send();
	}
</script>
<script>
function Confirmation(myId,OtherId){
	if(document.getElementById(OtherId).style.display === "none"){
		document.getElementById(myId).style.display='none';
		document.getElementById(OtherId).style.display="block";
		
		$(document).mouseup(function (e) {
       var container = $(".val");
       if (!container.is(e.target) && container.has(e.target).length === 0){
          document.getElementById(myId).style.display='block';
		  document.getElementById(OtherId).style.display="none";
       }

   });
	}else{
		document.getElementById(myId).style.display='block';
		document.getElementById(OtherId).style.display="none";
	}
	
	
}
</script>
<script>
	$(document).ready(function() {
    $('.Select2').select2();
});
</script>
<script>
	function changeTime(hour,timezone,date){
	var xhttp;    
	  if (timezone == "" && date=="" && hour=="") {
		document.getElementById("Ajax").innerHTML = "";
		return;
	  }
	  xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200){
		  document.getElementById("Ajax").innerHTML = this.responseText;
		  document.getElementById("myzone").innerHTML= "Your Time Zone: "+timezone;
		  document.getElementById("default").innerHTML= "";
		}
	  };
	  xhttp.open("GET", "change_houre.php?houre="+hour+"&timezone="+timezone+"&date="+date, true);
	  xhttp.send();
	}

</script>
<script>
function ChangeTimeZone(timezone,date){	
  var xhttp; 
	if(document.getElementById('12').checked) {
		var hour = 12;
	}else if(document.getElementById('24').checked) {
		var hour = 24;
	}
  if (timezone == "" && date=="") {
    document.getElementById("Ajax").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){
      document.getElementById("Ajax").innerHTML = this.responseText;
	  document.getElementById("myzone").innerHTML= "Your Time Zone: "+timezone;
	  document.getElementById("default").innerHTML= "";
    }
  };
  xhttp.open("GET", "ajax_times.php?timezone="+timezone+"&date="+date+"&houre="+hour, true);
  xhttp.send();
}
</script>


</body>
</html>
